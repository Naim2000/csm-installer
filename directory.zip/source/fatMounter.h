#include <stdbool.h>

bool mountSD();
void unmountSD();

bool mountUSB();
void unmountUSB();
