#include <stdbool.h>

bool isDolphin();
int patchIOS(bool vwii);
