#include <gctypes.h>

void initpads();
void scanpads();
void wait_button();
u32 buttons_down();
